$ErrorActionPreference = "Stop"

if (-not (Test-Path -Path "C:\temp")) {
    $null = New-Item -Path "C:\temp" -ItemType Directory -Force
}

$workingDir = "C:\temp\SCOM_Data"
if (Test-Path -Path $workingDir) {
    Remove-Item -Path $workingDir -Recurse -Force
}
$null = New-Item -Path $workingDir -ItemType Directory -Force

Import-Module OperationsManager -ErrorAction Stop

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$results = New-Object System.Collections.Generic.List[object]

$tasks = @(
    @{
        Name = "Get-SCOMManagementServer"
        Body = {
            Get-SCOMManagementServer |
                Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCOMManagementServer.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMGatewayManagementServer"
        Body = {
            Get-SCOMGatewayManagementServer |
                Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCOMGatewayManagementServer.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMAgent"
        Body = {
            Get-SCOMAgent |
                Export-Csv -Path (Join-Path $workingDir "2-Agent-Get-SCOMAgent.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCXAgent"
        Body = {
            Get-SCXAgent |
                Export-Csv -Path (Join-Path $workingDir "2-Agent-Get-SCXAgent.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMAgentlessManagedComputer"
        Body = {
            Get-SCOMAgentlessManagedComputer |
                Export-Csv -Path (Join-Path $workingDir "2-Agent-Get-SCOMAgentlessManagedComputer.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMResourcePool"
        Body = {
            Get-SCOMResourcePool |
                Export-Csv -Path (Join-Path $workingDir "3-Config-Get-SCOMResourcePool.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMManagementPack"
        Body = {
            Get-SCOMManagementPack |
                Export-Csv -Path (Join-Path $workingDir "3-Config-Get-SCOMManagementPack.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMRunAsAccount"
        Body = {
            Get-SCOMRunAsAccount |
                Export-Csv -Path (Join-Path $workingDir "3-Config-Get-SCOMRunAsAccount.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMPendingManagement"
        Body = {
            Get-SCOMPendingManagement |
                Export-Csv -Path (Join-Path $workingDir "4-Health-Get-SCOMPendingManagement.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
    @{
        Name = "Get-SCOMAlert-Last30Days"
        Body = {
            $alertSince = (Get-Date).AddDays(-30)
            Get-SCOMAlert |
                Where-Object {
                    ($_.TimeRaised -and $_.TimeRaised -ge $alertSince) -or
                    ($_.LastModified -and $_.LastModified -ge $alertSince)
                } |
                Export-Csv -Path (Join-Path $workingDir "4-Health-Get-SCOMAlert-Last30Days.csv") -Encoding UTF8 -NoTypeInformation
        }
    }
)

foreach ($task in $tasks) {
    $name = [string]$task.Name
    $body = [scriptblock]$task.Body
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    Write-Host "Running: $name"

    try {
        & $body

        $stopwatch.Stop()
        $results.Add([pscustomobject]@{
                Script     = $name
                Success    = $true
                ExitCode   = 0
                DurationMs = $stopwatch.ElapsedMilliseconds
                Error      = ""
            })
    }
    catch {
        $stopwatch.Stop()
        $results.Add([pscustomobject]@{
                Script     = $name
                Success    = $false
                ExitCode   = 1
                DurationMs = $stopwatch.ElapsedMilliseconds
                Error      = $_.Exception.Message
            })

        throw "Execution failed for '$name'. Error: $($_.Exception.Message)"
    }
}

$zipPath = "C:\temp\SCOM_Data_$timestamp.zip"
if (Test-Path -Path $zipPath) {
    Remove-Item -Path $zipPath -Force
}

Compress-Archive -Path (Join-Path $workingDir "*") -DestinationPath $zipPath -Force
Remove-Item -Path $workingDir -Recurse -Force

Write-Host ""
Write-Host "Run completed."
Write-Host "ZIP: $zipPath"
$results | Format-Table -AutoSize
