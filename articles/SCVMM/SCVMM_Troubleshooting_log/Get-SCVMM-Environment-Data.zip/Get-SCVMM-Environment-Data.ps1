param(
	[Parameter(Mandatory = $true)]
	[string]$VmmServerFqdn
)

$ContinueOnError = $false
$ErrorActionPreference = "Stop"

if (-not (Test-Path -Path "C:\temp")) {
	$null = New-Item -Path "C:\temp" -ItemType Directory -Force
}

$workingDir = "C:\temp\SCVMM_Data"
if (Test-Path -Path $workingDir) {
	Remove-Item -Path $workingDir -Recurse -Force
}
$null = New-Item -Path $workingDir -ItemType Directory -Force

Import-Module VirtualMachineManager -ErrorAction Stop

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$runId = "scvmm-no3-$timestamp"

$results = New-Object System.Collections.Generic.List[object]

$tasks = @(
	@{
		Name = "Get-SCVMMServer"
		Body = {
			Get-SCVMMServer -ComputerName $VmmServerFqdn |
				Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCVMMServer.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVMHost"
		Body = {
			Get-SCVMHost |
				Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCVMHost.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVMHostCluster"
		Body = {
			Get-SCVMHostCluster |
				Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCVMHostCluster.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVMMManagedComputer"
		Body = {
			Get-SCVMMManagedComputer |
				Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCVMMManagedComputer.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVirtualMachine"
		Body = {
			Get-SCVirtualMachine |
				Export-Csv -Path (Join-Path $workingDir "1-Basic-Get-SCVirtualMachine.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCCloud"
		Body = {
			Get-SCCloud |
				Export-Csv -Path (Join-Path $workingDir "3-Cloud-Get-SCCloud.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCUserRole"
		Body = {
			Get-SCUserRole |
				Export-Csv -Path (Join-Path $workingDir "3-Cloud-Get-SCUserRole.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCLibraryServer"
		Body = {
			Get-SCLibraryServer |
				Export-Csv -Path (Join-Path $workingDir "4-Library-Get-SCLibraryServer.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCLibraryShare"
		Body = {
			Get-SCLibraryShare |
				Export-Csv -Path (Join-Path $workingDir "4-Library-Get-SCLibraryShare.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVMTemplate"
		Body = {
			Get-SCVMTemplate |
				Export-Csv -Path (Join-Path $workingDir "4-Library-Get-SCVMTemplate.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCHardwareProfile"
		Body = {
			Get-SCHardwareProfile |
				Export-Csv -Path (Join-Path $workingDir "4-Library-Get-SCHardwareProfile.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCGuestOSProfile"
		Body = {
			Get-SCGuestOSProfile |
				Export-Csv -Path (Join-Path $workingDir "4-Library-Get-SCGuestOSProfile.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCLogicalNetwork"
		Body = {
			Get-SCLogicalNetwork |
				Export-Csv -Path (Join-Path $workingDir "5-Network-Get-SCLogicalNetwork.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCVMNetwork"
		Body = {
			Get-SCVMNetwork |
				Export-Csv -Path (Join-Path $workingDir "5-Network-Get-SCVMNetwork.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCLogicalSwitch"
		Body = {
			Get-SCLogicalSwitch |
				Export-Csv -Path (Join-Path $workingDir "5-Network-Get-SCLogicalSwitch.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCPortClassification"
		Body = {
			Get-SCPortClassification |
				Export-Csv -Path (Join-Path $workingDir "5-Network-Get-SCPortClassification.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCStorageProvider"
		Body = {
			Get-SCStorageProvider |
				Export-Csv -Path (Join-Path $workingDir "2-Storage-Get-SCStorageProvider.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCStorageArray"
		Body = {
			Get-SCStorageArray |
				Export-Csv -Path (Join-Path $workingDir "2-Storage-Get-SCStorageArray.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCStoragePool"
		Body = {
			Get-SCStoragePool |
				Export-Csv -Path (Join-Path $workingDir "2-Storage-Get-SCStoragePool.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCStorageClassification"
		Body = {
			Get-SCStorageClassification |
				Export-Csv -Path (Join-Path $workingDir "2-Storage-Get-SCStorageClassification.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
	@{
		Name = "Get-SCJob-Last30Days"
		Body = {
			$jobSince = (Get-Date).AddDays(-30)
			Get-SCJob |
				Where-Object {
					($_.StartTime -and $_.StartTime -ge $jobSince) -or
					($_.ModifiedTime -and $_.ModifiedTime -ge $jobSince)
				} |
				Export-Csv -Path (Join-Path $workingDir "6-Job-Get-SCJob-Last30Days.csv") -Encoding UTF8 -NoTypeInformation
		}
	}
)

if ($tasks.Count -lt 5) {
	throw "At least 5 script blocks are required. Current count: $($tasks.Count)"
}

foreach ($task in $tasks) {
	$name = [string]$task.Name
	$body = [scriptblock]$task.Body
	$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

	Write-Host "Running: $name"

	try {
		& $body

		$stopwatch.Stop()
		$results.Add([pscustomobject]@{
				Script     = $name
				Success    = $true
				ExitCode   = 0
				DurationMs = $stopwatch.ElapsedMilliseconds
				RunId      = $runId
				Error      = ""
			})
	}
	catch {
		$stopwatch.Stop()
		$results.Add([pscustomobject]@{
				Script     = $name
				Success    = $false
				ExitCode   = 1
				DurationMs = $stopwatch.ElapsedMilliseconds
				RunId      = $runId
				Error      = $_.Exception.Message
			})

		if (-not $ContinueOnError) {
			throw "Execution failed for '$name'. Error: $($_.Exception.Message)"
		}
	}
}

$zipPath = "C:\temp\SCVMM_Data_$timestamp.zip"
if (Test-Path -Path $zipPath) {
	Remove-Item -Path $zipPath -Force
}

Compress-Archive -Path (Join-Path $workingDir "*") -DestinationPath $zipPath -Force
Remove-Item -Path $workingDir -Recurse -Force

Write-Host ""
Write-Host "Run completed."
Write-Host "ZIP: $zipPath"
$results | Format-Table -AutoSize
